#Biopython package -- bringing in SeqIO to parse NGS data and SeqUtils to
#search for a sequence motif immediately preceding the barcode
#Top strand prior to PCR reaction: cgcagcgaccaccctttNNNNNNNNNGGCGTCATCGTGTACCGG
#Search motif is lowercase

from Bio import SeqIO, SeqUtils

#Forward of paired-end reads across a triplicate of experiments
Samp_1_F = open("Sample1_R1_001.fastq", "r")
Samp_2_F = open("Sample2_R1_001.fastq", "r")
Samp_3_F = open("Sample3_R1_001.fastq", "r")

#Reverse of paired-end reads across a triplicate of experiments
Samp_1_R = open("Sample1_R2_001.fastq", "r")
Samp_2_R = open("Sample2_R2_001.fastq", "r")
Samp_3_R = open("Sample3_R2_001.fastq", "r")

#TGT counter function that takes in a fastq NGS sequencing file and 
#a way to define if the data is a forward or reverse read
#i.e., forward = True or = False
def tgt_counter(data, forward):
    
    seq_dict = {}
    
    for record in SeqIO.parse(data, "fastq"):
        if forward == True:
            new = SeqUtils.nt_search(str(record.seq), "CGCAGCGACCACCCTTT")
            if len(new) > 1:
                seq = record.seq[new[1]+17:new[1]+25]
                if seq in seq_dict:
                    seq_dict[str(seq)] += 1
                else:
                    seq_dict[str(seq)] = 1
        else:
            new = SeqUtils.nt_search(str(record.seq.reverse_complement()), "CGCAGCGACCACCCTTT")
            if len(new) > 1:
                seq = record.seq.reverse_complement()[new[1]+17:new[1]+25]
                if seq in seq_dict:
                    seq_dict[str(seq)] += 1
                else:
                    seq_dict[str(seq)] = 1
                
    return(seq_dict)

s1f = tgt_counter(Samp_1_F, forward = True)
s2f = tgt_counter(Samp_2_F, forward = True)
s3f = tgt_counter(Samp_3_F, forward = True)

s1r = tgt_counter(Samp_1_R, forward = False)
s2r = tgt_counter(Samp_2_R, forward = False)
s3r = tgt_counter(Samp_3_R, forward = False)

#Low quality sequncing flood the counting dictionary with low-fidelity barcodes
#and nonspecific sequence
#These are ignored by pulling out the counts for specifically the three barcodes
#and excluding all other information
def combo(forward, reverse):

    dict_list = [forward, reverse]
    
    Con_1 = 0
    Con_2 = 0
    Con_3 = 0
    
    for i in dict_list:
        Con_1 += (i["AGACTCTT"])
        Con_2 += (i["TCTGAGTT"])
        Con_3 += (i["TCTCTCTT"])
        
    expo = [Con_1, Con_2, Con_3]
    
    return(expo)

S1Combo = combo(s1f, s1r)
S2Combo = combo(s2f, s2r)
S3Combo = combo(s3f, s3r)

#Data output

out = open("TGT_NGS_DATA.txt", "w")

print("NGS_Barcode" + "\t" + "Sample_1" + "\t" + "Sample_2" + "\t" + "Sample_3", file = out)
print("AGACTCTT" + "\t" + str(S1Combo[0]) + "\t" + str(S2Combo[0]) + "\t" + str(S3Combo[0]), file = out)
print("TCTGAGTT" + "\t" + str(S1Combo[1]) + "\t" + str(S2Combo[1]) + "\t" + str(S3Combo[1]), file = out)
print("TCTCTCTT" + "\t" + str(S1Combo[2]) + "\t" + str(S2Combo[2]) + "\t" + str(S3Combo[2]), file = out)

out.close()
